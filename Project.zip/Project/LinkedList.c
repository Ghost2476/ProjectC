#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "scene.h"



SceneNode* head = NULL;

void insertLinkedList(Scene s) {
    SceneNode* newNode = (SceneNode*)malloc(sizeof(SceneNode));
    newNode->data = s;
    newNode->next = NULL;
    if (!head) {
        head = newNode;
    } else {
        SceneNode* temp = head;
        while (temp->next) temp = temp->next;
        temp->next = newNode;
    }
}

void displayLinkedList() {
    SceneNode* temp = head;
    if (!temp) {
        printf("Linked list is empty!\n");
        return;
    }
    while (temp) {
        displayScene(temp->data);
        temp = temp->next;
    }
}
SceneNode* getLinkedListHead() {
    return head;
}


SceneNode* getLastSceneNode() {
    SceneNode* temp = head;
    if (!temp) return NULL;  
    
    while (temp->next != NULL) {
        temp = temp->next;
    }
    return temp;
}
