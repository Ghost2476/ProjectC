#include <gtk/gtk.h>
#include "scene.h"
#include <string.h>
#include <stdlib.h>
#include <gdk/gdkx.h>
#include <gst/video/videooverlay.h>

GtkWidget *drawing_area;
static void on_video_end(GstBus *bus, GstMessage *msg, gpointer user_data) {
    GstElement *playbin = GST_ELEMENT(user_data);
    gst_element_seek(playbin,1.0, GST_FORMAT_TIME,GST_SEEK_FLAG_FLUSH | GST_SEEK_FLAG_ACCURATE,GST_SEEK_TYPE_SET, 0,GST_SEEK_TYPE_NONE, GST_CLOCK_TIME_NONE);
}

static void on_realize(GtkWidget *widget, gpointer user_data) {
    GstElement *playbin = GST_ELEMENT(user_data);
    GstVideoOverlay *overlay = GST_VIDEO_OVERLAY(playbin);


    GdkWindow *gdk_window = gtk_widget_get_window(widget);
    if (gdk_window != NULL) {
        guintptr window_id = GDK_WINDOW_XID(gdk_window);
        gst_video_overlay_set_window_handle(overlay, window_id);
    }
}
void open_add_scene_window(GtkWidget *widget, gpointer data);
void on_submit_scene_clicked(GtkWidget *widget, gpointer data);


static void activate(GtkApplication *app, gpointer user_data) {
    GtkWidget *window;
    GtkWidget *overlay;
    GtkWidget *video_area;
    GtkWidget *button_box;
    GtkWidget *add_button, *check_stack_button, *check_queue_button;


    window = gtk_application_window_new(app);
    gtk_window_set_title(GTK_WINDOW(window), "🧠 Souvenir Box");
    gtk_window_set_default_size(GTK_WINDOW(window), 640, 480);


    overlay = gtk_overlay_new();
    gtk_container_add(GTK_CONTAINER(window), overlay);

    video_area = gtk_drawing_area_new();
    gtk_widget_set_size_request(video_area, 640, 480);
    gtk_overlay_add_overlay(GTK_OVERLAY(overlay), video_area);  // Bottom layer


    GstElement *playbin = gst_element_factory_make("playbin", "playbin");
    g_object_set(playbin, "uri", "file:///home/ghost/2emetic/C2nd/Project/prC/N.mp4", NULL);


    g_signal_connect_after(video_area, "realize", G_CALLBACK(on_realize), playbin);


    button_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_widget_set_halign(button_box, GTK_ALIGN_CENTER);
    gtk_widget_set_valign(button_box, GTK_ALIGN_CENTER);
    gtk_overlay_add_overlay(GTK_OVERLAY(overlay), button_box);  // On top


    GtkCssProvider *provider = gtk_css_provider_new();
    gtk_css_provider_load_from_data(provider,
        "box { background-color: rgba(0, 0, 0, 0.6); padding: 20px; border-radius: 10px; }"
        "button { color: white; font-weight: bold; font-size: 16px; }",
        -1, NULL);
    gtk_style_context_add_provider_for_screen(
        gdk_screen_get_default(),
        GTK_STYLE_PROVIDER(provider),
        GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);

    gtk_container_set_border_width(GTK_CONTAINER(button_box), 20);

    add_button = gtk_button_new_with_label("➕ Add Scene");
    check_stack_button = gtk_button_new_with_label("📚 Check Stack");
    check_queue_button = gtk_button_new_with_label("⏩ Check Queue");

    gtk_box_pack_start(GTK_BOX(button_box), add_button, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(button_box), check_stack_button, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(button_box), check_queue_button, FALSE, FALSE, 0);

    g_signal_connect(add_button, "clicked", G_CALLBACK(open_add_scene_window), NULL);
    g_signal_connect(check_stack_button, "clicked", G_CALLBACK(open_check_list_window), NULL);
    g_signal_connect(check_queue_button, "clicked", G_CALLBACK(open_check_last_scene_window), NULL);

    gtk_widget_show_all(window);
    gst_element_set_state(playbin, GST_STATE_PLAYING);
    GstBus *bus = gst_element_get_bus(playbin);
    gst_bus_add_signal_watch(bus);
    g_signal_connect(bus, "message::eos", G_CALLBACK(on_video_end), playbin);
    gst_object_unref(bus);

}

void open_check_list_window(GtkWidget *widget, gpointer data) {
    GtkWidget *window, *box, *label;
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Check List");
    gtk_window_set_default_size(GTK_WINDOW(window), 400, 300);

    box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_container_set_border_width(GTK_CONTAINER(box), 20);
    gtk_container_add(GTK_CONTAINER(window), box);


    SceneNode* current = head;
    if (!current) {
    GtkWidget *label = gtk_label_new("No scenes found.");
    gtk_box_pack_start(GTK_BOX(box), label, TRUE, TRUE, 0);
    }else {
    while (current) {
        char scene_text[1024];
        snprintf(scene_text, sizeof(scene_text),
            "Description: %s\nDate: %s\nTime: %s\nLocation: %s\nEmotion: %s\nIntensity: %d\nType: %s\nTags: %s, %s, %s\n",
            current->data.description, current->data.date, current->data.time,
            current->data.location, current->data.emotion, current->data.intensity,
            current->data.type, current->data.tags[0], current->data.tags[1], current->data.tags[2]);

        GtkWidget *label = gtk_label_new(scene_text);
        gtk_label_set_xalign(GTK_LABEL(label), 0);  
        gtk_box_pack_start(GTK_BOX(box), label, FALSE, FALSE, 5);

        current = current->next;
    }
    }

    gtk_widget_show_all(window);
}

void open_check_last_scene_window(GtkWidget *widget, gpointer data) {
    GtkWidget *window, *box, *label;
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Check Last Scene");
    gtk_window_set_default_size(GTK_WINDOW(window), 400, 200);

    box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_container_set_border_width(GTK_CONTAINER(box), 20);
    gtk_container_add(GTK_CONTAINER(window), box);


    SceneNode* lastSceneNode = getLastSceneNode();
    
    if (lastSceneNode != NULL) {
 
        char last_scene_info[512];
        snprintf(last_scene_info, sizeof(last_scene_info),
                 "Description: %s\n"
                 "Date: %s\n"
                 "Time: %s\n"
                 "Location: %s\n"
                 "Emotion: %s",
                 lastSceneNode->data.description,
                 lastSceneNode->data.date,
                 lastSceneNode->data.time,
                 lastSceneNode->data.location,
                 lastSceneNode->data.emotion);

        label = gtk_label_new(last_scene_info);
        gtk_box_pack_start(GTK_BOX(box), label, TRUE, TRUE, 0);
    } else {

        label = gtk_label_new("No scenes found.");
        gtk_box_pack_start(GTK_BOX(box), label, TRUE, TRUE, 0);
    }

    gtk_widget_show_all(window);
}



void open_add_scene_window(GtkWidget *widget, gpointer data) {
    GtkWidget *window, *main_box, *form_box, *submit_button, *title;

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Add Scene");
    gtk_window_set_default_size(GTK_WINDOW(window), 400, 500);
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);

    main_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 20);
    gtk_container_set_border_width(GTK_CONTAINER(main_box), 30);
    gtk_container_add(GTK_CONTAINER(window), main_box);

    title = gtk_label_new("\xE2\x9E\x95 Add New Scene");
    gtk_widget_set_halign(title, GTK_ALIGN_CENTER);
    gtk_widget_set_margin_bottom(title, 20);
    gtk_box_pack_start(GTK_BOX(main_box), title, FALSE, FALSE, 0);

    form_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_widget_set_halign(form_box, GTK_ALIGN_CENTER);
    gtk_box_pack_start(GTK_BOX(main_box), form_box, TRUE, TRUE, 0);

    GtkWidget **entries = g_new(GtkWidget*, 10);
    const char *placeholders[] = {
        "Description", "Date (YYYY-MM-DD)", "Time (HH:MM:SS)", "Location",
        "Emotion", "Intensity (1-10)", "Type", "Tag 1", "Tag 2", "Tag 3"
    };
    const char *labels[] = {
        "Description:", "Date:", "Time:", "Location:", 
        "Emotion:", "Intensity:", "Type:", "Tag 1:", "Tag 2:", "Tag 3:"
    };
    for (int i = 0; i < 10; i++) {
        GtkWidget *label = gtk_label_new(labels[i]);
        gtk_box_pack_start(GTK_BOX(form_box), label, FALSE, FALSE, 0);
        entries[i] = gtk_entry_new();
        gtk_entry_set_placeholder_text(GTK_ENTRY(entries[i]), placeholders[i]);
        gtk_box_pack_start(GTK_BOX(form_box), entries[i], FALSE, FALSE, 0);
    }

    submit_button = gtk_button_new_with_label("\xE2\x9C\x94 Submit Scene");
    gtk_widget_set_margin_top(submit_button, 15);
    gtk_box_pack_start(GTK_BOX(form_box), submit_button, FALSE, FALSE, 0);

    g_signal_connect(submit_button, "clicked", G_CALLBACK(on_submit_scene_clicked), entries);

    gtk_widget_show_all(window);
}

void on_submit_scene_clicked(GtkWidget *widget, gpointer data) {
    GtkWidget **entries = (GtkWidget **)data;
    Scene s;

    strcpy(s.description, gtk_entry_get_text(GTK_ENTRY(entries[0])));
    strcpy(s.date, gtk_entry_get_text(GTK_ENTRY(entries[1])));
    strcpy(s.time, gtk_entry_get_text(GTK_ENTRY(entries[2])));
    strcpy(s.location, gtk_entry_get_text(GTK_ENTRY(entries[3])));
    strcpy(s.emotion, gtk_entry_get_text(GTK_ENTRY(entries[4])));
    s.intensity = atoi(gtk_entry_get_text(GTK_ENTRY(entries[5])));
    strcpy(s.type, gtk_entry_get_text(GTK_ENTRY(entries[6])));
    strcpy(s.tags[0], gtk_entry_get_text(GTK_ENTRY(entries[7])));
    strcpy(s.tags[1], gtk_entry_get_text(GTK_ENTRY(entries[8])));
    strcpy(s.tags[2], gtk_entry_get_text(GTK_ENTRY(entries[9])));


    if (sceneExactlyExists(s)) {
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_DESTROY_WITH_PARENT,GTK_MESSAGE_WARNING, GTK_BUTTONS_OK,"This scene happened exactly.");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }

    else if (sceneAlreadyHappened(s)) {
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_DESTROY_WITH_PARENT,GTK_MESSAGE_WARNING, GTK_BUTTONS_OK,"Déjà vu! This scene already exists.");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }
    else {
        push(s);
        enqueue(s);
        insertLinkedList(s);
        if (sceneCount < MAX_SCENES) {
            scenes[sceneCount++] = s;
        }
    
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_DESTROY_WITH_PARENT, GTK_MESSAGE_INFO,GTK_BUTTONS_OK, "Scene added successfully!");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    }
    }
    


int main(int argc, char **argv) {
    gtk_init(&argc, &argv);
    gst_init(&argc, &argv);
    GtkApplication *app;
    int status;

    app = gtk_application_new("org.souvenirbox.app", G_APPLICATION_DEFAULT_FLAGS);
    g_signal_connect(app, "activate", G_CALLBACK(activate), NULL);
    status = g_application_run(G_APPLICATION(app), argc, argv);
    g_object_unref(app);

    return status;
}
