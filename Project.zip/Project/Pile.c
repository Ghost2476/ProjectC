
#include <stdio.h>
#include "scene.h"

static Scene stack[MAX_SCENES];
static int top = -1;

void push(Scene s) {
    if (top < MAX_SCENES - 1) {
        stack[++top] = s;
    } else {
        printf("Stack is full!\n");
    }
}

Scene pop() {
    if (top >= 0) {
        return stack[top--];
    } else {
        printf("Stack is empty!\n");
        Scene empty = {0};
        return empty;
    }
}
