
#include <stdio.h>
#include <string.h>
#include "scene.h"

static Scene queue[MAX_SCENES];
static int front = 0, rear = -1, qCount = 0;

void enqueue(Scene s) {
    if (qCount < MAX_SCENES) {
        rear = (rear + 1) % MAX_SCENES;
        queue[rear] = s;
        qCount++;
    } else {
        printf("Queue is full!\n");
    }
}

Scene dequeue() {
    if (qCount > 0) {
        Scene s = queue[front];
        front = (front + 1) % MAX_SCENES;
        qCount--;
        return s;
    } else {
        printf("Queue is empty!\n");
        Scene empty = {0};
        return empty;
    }
}
