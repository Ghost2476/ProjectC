
#include "scene.h"

Scene scenes[MAX_SCENES];
int sceneCount = 0;
