
#ifndef SCENE_H
#define SCENE_H

#define MAX_SCENES 100
#include <gtk/gtk.h>

typedef struct Scene {
    char description[256];
    char date[11];
    char time[9];
    char location[100];
    char emotion[50];
    int intensity;
    char type[50];
    char tags[3][50];
} Scene;

typedef struct SceneNode {
    Scene data;
    struct SceneNode* next;
} SceneNode;
extern SceneNode* head;
extern Scene scenes[MAX_SCENES];
extern int sceneCount;


void push(Scene s);
Scene pop();
void enqueue(Scene s);
Scene dequeue();
void insertLinkedList(Scene s);
void displayLinkedList();
SceneNode* getLastSceneNode(); 
void displayScene(Scene s);
Scene inputScene();

int sceneAlreadyHappened(Scene s);
int sceneExactlyExists(Scene s);

void open_check_list_window(GtkWidget *widget, gpointer data);
void open_check_last_scene_window(GtkWidget *widget, gpointer data);


#endif
