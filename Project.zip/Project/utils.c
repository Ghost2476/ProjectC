#include <stdio.h>
#include <string.h>
#include "scene.h"
#include <gtk/gtk.h>


void displayScene(Scene s) {
    printf("\n--- Scene ---\n");
    printf("Description: %s\n", s.description);
    printf("Date: %s\n", s.date);
    printf("Time: %s\n", s.time);
    printf("Location: %s\n", s.location);
    printf("Emotion: %s\n", s.emotion);
    printf("Intensity: %d\n", s.intensity);
    printf("Type: %s\n", s.type);
    printf("Tags: %s, %s, %s\n", s.tags[0], s.tags[1], s.tags[2]);
    printf("---------------\n");
}

Scene inputScene() {
    Scene s;
    getchar();

    printf("Enter description: ");
    fgets(s.description, sizeof(s.description), stdin);
    s.description[strcspn(s.description, "\n")] = 0;

    printf("Enter date (YYYY-MM-DD): ");
    scanf("%10s", s.date);

    printf("Enter time (HH:MM:SS): ");
    scanf("%8s", s.time);

    printf("Enter location: ");
    scanf("%99s", s.location);

    printf("Enter emotion: ");
    scanf("%49s", s.emotion);

    printf("Enter intensity (1-10): ");        
}


int sceneAlreadyHappened(Scene s) {
    int sc=0;
    for (int i = 0; i < sceneCount; i++) {
        if (strcmp(scenes[i].location, s.location) == 0 )
            sc++;
        if (strcmp(scenes[i].emotion, s.emotion) == 0 )
            sc++;
        if ( scenes[i].intensity == s.intensity )
            sc++;
        if (strcmp(scenes[i].type, s.type) == 0)
            sc++;
        
        
        
    }
    if(sc>=4)    return 1;
    return 0;
    
}

int sceneExactlyExists(Scene s) {
    for (int i = 0; i < sceneCount; i++) {
        Scene existing = scenes[i];
        if (strcmp(existing.description, s.description) == 0 &&
            strcmp(existing.date, s.date) == 0 &&
            strcmp(existing.time, s.time) == 0 &&
            strcmp(existing.location, s.location) == 0 &&
            strcmp(existing.emotion, s.emotion) == 0 &&
            existing.intensity == s.intensity &&
            strcmp(existing.type, s.type) == 0 &&
            strcmp(existing.tags[0], s.tags[0]) == 0 &&
            strcmp(existing.tags[1], s.tags[1]) == 0 &&
            strcmp(existing.tags[2], s.tags[2]) == 0) {
            return 1;
        }
    }
    return 0;
}
